package pruebas;
import aplicacion.*;
import presentacion.*;
import static org.junit.Assert.*;
import org.junit.Test;
import java.util.ArrayList;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.function.*;
import java.io.*;
/**
 * The test class SenkuTest.
 *
 * @author  Juan Camilo P.
 * @version (a version number or a date)
 */
public class AutomataGUITest
{   
    /**
     * Default constructor for test class SenkuTest
     */
	private AutomataCelular ac;
	private AutomataGUI ca;
    public AutomataGUITest() {
        ac=new AutomataCelular();
        ca=new AutomataGUI(ac);
    }
	@Test
    public void deberiaLanzarErrorAlAbrirUnArchivoNoValido() {
	try {
			File unAutomata = new File("auto");
			ac.abrir(unAutomata);
			fail ("no lanzó excepcion");
	}  catch (ClassNotFoundException e) {
	} catch (automataException e) {	
				assertEquals(e.getMessage(),automataException.ERROR_AL_ABRIR);
	}
	}
	
		@Test
    public void deberiaLanzarExcepcionSiSeAbreUnArchivoQueNoExiste() {
	try {
			File unAutomata = new File("auto.f");
			
			ac.abrir(unAutomata);
			fail ("no lanzó excepcion");
	}  catch (ClassNotFoundException e) {
		assertEquals(e.getMessage(),automataException.ARCHIVO_NO_EXISTE);
	} catch (automataException e) {	
				assertEquals(e.getMessage(),automataException.ERROR_AL_ABRIR);
	}
	}
	
}
