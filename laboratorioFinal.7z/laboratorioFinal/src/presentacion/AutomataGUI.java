package presentacion;
import aplicacion.*;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.function.*;
import java.io.*;

public class AutomataGUI extends JFrame{	

	private static Registro registro = new Registro();
    private JButton botonReloj;
    private JLabel lFila;
    private JLabel lColumna;
    private JTextField tFila;
    private JTextField tColumna;
    private JPanel panelControl;
    private JPanel panelNueva;
    private JPanel panelBNueva;
	private JMenuBar menuF;
	private JMenu menusito;
	private JMenuItem reiniciar;
	private JMenuItem salve;
	private JMenuItem abra;
	private JMenuItem exportar;
	private JMenuItem importar;
	private JMenu menusito2;
	private JMenuItem salir;
	private JMenuItem iniciar;
    private JButton botonViva;
    private JButton botonLatente;
    private FotoAutomata foto;
    private AutomataCelular automata=null;

    public AutomataGUI(AutomataCelular ac) {
        super("Automata celular");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        automata=ac;
        foto=new FotoAutomata(automata);
        setSize(new Dimension(502,570)); 
		prepareElementosMenu();
		prepareAccionesMenu();
        prepareElementos();
        prepareAcciones();

    }

    private void prepareElementos() {
        setResizable(false);
		

        botonReloj=new JButton("Tic-tac");


        getContentPane().setLayout(new BorderLayout());
		getContentPane().add(menuF,BorderLayout.NORTH);
        getContentPane().add(foto,BorderLayout.CENTER);
        getContentPane().add(botonReloj,BorderLayout.SOUTH);
        foto.repaint();
    }
	private void prepareElementosMenu(){
		menuF=new JMenuBar();
		
		/*menu*/
		menusito2=new JMenu("Menu");
		
		menuF.add(menusito2);
		salir = new JMenuItem("Salir",KeyEvent.VK_L);
		iniciar = new JMenuItem("Iniciar",KeyEvent.VK_N);
		menusito2.add(iniciar);
		menusito2.add(salir);
		
		/*Archivo*/
		menusito=new JMenu("Archivo");
		
		menuF.add(menusito);
		reiniciar = new JMenuItem("Reiniciar",KeyEvent.VK_R);
		salve = new JMenuItem("Salve",KeyEvent.VK_S);
		abra = new JMenuItem("Abra",KeyEvent.VK_A);
		exportar = new JMenuItem("Exportar",KeyEvent.VK_E);
		importar = new JMenuItem("Importar",KeyEvent.VK_I);

		menusito.add(reiniciar);
		menusito.add(salve);
		menusito.add(abra);
		menusito.add(exportar);
		menusito.add(importar);
		
	}
	
	
	
    private void prepareAcciones(){

        botonReloj.addActionListener(
            new ActionListener(){
                public void actionPerformed(ActionEvent e) {
                    botonRelojAccion();
                }
            });
			
	}
	private void prepareAccionesMenu(){
		/*Archivo menu*/
		salve.addActionListener(
            new ActionListener(){
                public void actionPerformed(ActionEvent e) {
						opcionSalvar();
                }
            });
		
		abra.addActionListener(
            new ActionListener(){
                public void actionPerformed(ActionEvent e) {
						opcionAbrir();
                }
            });
			
		
		exportar.addActionListener(
            new ActionListener(){
                public void actionPerformed(ActionEvent e) {
					File algo=intento(new JFileChooser(),f->f.showSaveDialog(exportar));
						exportarJuego(algo);
                }
            });
			
		importar.addActionListener(
            new ActionListener(){
                public void actionPerformed(ActionEvent e) {
					File algo=intento(new JFileChooser(),f->f.showOpenDialog(importar));
						importarJuego(algo);
				}
            });
			
		reiniciar.addActionListener(
            new ActionListener(){
                public void actionPerformed(ActionEvent e) {
					try{
						reiniciarJuego();
					}
					catch(automataException ie){
						JOptionPane.showMessageDialog(null,ie.getMessage(),"ERROR",JOptionPane.INFORMATION_MESSAGE);
					}
                }
            });
			
			
		/*Menú*/
		iniciar.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent ev){
				opcionIniciar();
			}
		});
		salir.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent ev){
				opcionSalir();
			}
		});	
	}
    private void botonRelojAccion() {
        automata.ticTac();
        foto.repaint();
    }
	
	private void opcionSalir(){
		this.dispose();
		System.exit(0);
	}
	
	private void opcionIniciar(){
		automata=new AutomataCelular();
	}
	 

    public static void main(String[] args) {
        AutomataCelular ac=new AutomataCelular();
        AutomataGUI ca=new AutomataGUI(ac);
        ca.setVisible(true);

    } 
	
	public void opcionSalvar() {
	File unAutomata=intento(new JFileChooser(),f->f.showSaveDialog(salve));
	if(unAutomata!=null){try {
		automata.salve(unAutomata);
		
	} catch (automataException e) {
				JOptionPane.showMessageDialog(null,e.getMessage(),"ERROR",JOptionPane.INFORMATION_MESSAGE);
			}
	}}
	public void opcionAbrir(){
	File unAutomata=intento(new JFileChooser(),f->f.showOpenDialog(abra));
	if(unAutomata!=null){try {
				automata.abrir(unAutomata);
				repaint();
	} catch (ClassNotFoundException e) {
		JOptionPane.showMessageDialog(null,"El archivo no es legible, intente de nuevo","ERROR",JOptionPane.INFORMATION_MESSAGE);
	} catch (automataException e) {
				JOptionPane.showMessageDialog(null,e.getMessage(),"ERROR",JOptionPane.INFORMATION_MESSAGE);
			}
	}}
	public void exportarJuego(File archivo) {
		try{
		automata.exportar(archivo);
		}
		catch(FileNotFoundException fn){
			registro.registre(fn);
			System.out.println(fn.getMessage());
		}
	}
	
	public void importarJuego(File archivo) {
		try{
		automata.importar(archivo);
		foto.repaint();
		}
		catch(FileNotFoundException fn){
			registro.registre(fn);	
			System.out.println(fn.getMessage());
		}
		catch(IOException ioe){
			registro.registre(ioe);
			System.out.println("wwww");
			System.out.println(ioe.getMessage());
		}
	}
	
	public void reiniciarJuego() throws automataException{
		throw new automataException(automataException.BOTON_EN_CONSTRUCCION);
	}
	
	public void saveOpenChooser(Component par){
		intento(new JFileChooser(),f->f.showOpenDialog(par));
		JFileChooser fc=new JFileChooser();
	}
	
	public File intento(JFileChooser g,Consumer<JFileChooser> c){
		c.accept(g);
		return g.getSelectedFile();
	}
}


class FotoAutomata extends JPanel{
    public static int TAMANO=40;
    private AutomataCelular automata;

    public FotoAutomata(AutomataCelular ac) {
        setBackground(Color.white);
        automata=ac;
        setPreferredSize(new Dimension(800,800)); 		

    }

    public void setAutomata(AutomataCelular automata){
        this.automata=automata;
    }

    public void paintComponent(Graphics g){
        super.paintComponent(g);

        for (int f=0;f<=automata.getLongitud();f++){
            g.drawLine(f*TAMANO,0,f*TAMANO,automata.getLongitud()*TAMANO);
        }
        for (int c=0;c<=automata.getLongitud();c++){
            g.drawLine(0,c*TAMANO,automata.getLongitud()*TAMANO,c*TAMANO);
        }		
        for (int f=0;f<automata.getLongitud();f++){
            for(int c=0;c<automata.getLongitud();c++){
                if (automata.getElemento(f,c)!=null){
                    g.setColor(automata.getElemento(f,c).getColor());
                    if (! (automata.getElemento(f,c) instanceof Celula)){
                       g.fillRoundRect(TAMANO*c+3,TAMANO*f+3,16,16,5,5); 
                       g.fillRoundRect(TAMANO*c+3+18,TAMANO*f+3,16,16,5,5); 
                       g.fillRoundRect(TAMANO*c+3,TAMANO*f+3+18,16,16,5,5); 
                       g.fillRoundRect(TAMANO*c+3+18,TAMANO*f+3+18,16,16,5,5);                       
                       if (automata.getElemento(f,c).isVivo()){
                        g.fillRoundRect(TAMANO*c+3,TAMANO*f+3,35,35,5,5);
                       }
                    }else {
                        if (automata.getElemento(f,c).isVivo()){
                            g.fillOval(TAMANO*c+10,TAMANO*f+10,20,20);
                        } else {
                            g.drawOval(TAMANO*c+10,TAMANO*f+10,20,20);
                        }
                    }
                }
            }
        }
    }
}