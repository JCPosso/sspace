package aplicacion;
import java.awt.Color;
import java.io.Serializable;
public interface Elemento extends Serializable {
    
  void decida(AutomataCelular ac);
  void cambie();
  void rejuvenezca();
  String getIndicador();
  String getAttri();
  
  default Color getColor(){
      return Color.RED;
  } 
  
  default boolean isVivo(){
      return true;
  }
  default int  verificar(AutomataCelular ac , int ii , int jj){
      Integer[] I= {-1,0,1,1,-1,1,-1,0,1};
      Integer[] J= {-1,-1,-1,0,0,1,1,1,1};
      int celulasVivas=0;
      for (int i=0 ;i<8;i++){
          System.out.println(ii);
          System.out.println(jj);
          if (0<ii+I[i]&& ii+I[i]<19 && 0<jj+J[i] && jj+J[i]<19 ) { 
              
              if(ac.getElemento(ii+I[i],jj+J[i]) instanceof Celula ){
                  if (ac.getElemento(ii+I[i],jj+J[i]).isVivo()){
                      celulasVivas++;
                    }
                }
            }
        }
      return celulasVivas;
    }
}
