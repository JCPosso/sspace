package aplicacion;
import java.awt.Color;

/**
 * Write a description of class Izquierdozas here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Sacrificio extends Celula
{
    /**
     * Constructor for objects of class Izquierdozas
     */
    public  Sacrificio(AutomataCelular ac,int fila, int columna)
    {
        super(ac,fila,columna);
        this.color=color.yellow;
    }
    public Color getColor(){
        return this.color;
    }
    public void decida(AutomataCelular ac){
        int j = getColumna();
        int i = getFila();
        if (  ac.getElemento(i,j+1)instanceof Celula  ){
            if(  
            ac.getElemento(i,j).isVivo()){
                ac.getElemento(i,j+1).rejuvenezca();
            }
        }
        super.estadoSiguiente=MUERTA;
    }
	
	public String getIndicador(){
		return "Sa";
	}

}