package aplicacion;
import java.awt.Color;

/**
 * Write a description of class Izquierdozas here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Resucitar extends Celula
{
    /**
     * Constructor for objects of class Izquierdozas
     */
    public  Resucitar(AutomataCelular ac,int fila, int columna)
    {
        super(ac,fila,columna);
        this.color=color.pink;
    }
    public Color getColor(){
        return this.color;
    }
    public void decida(AutomataCelular ac){
        int j = getColumna();
        int i = getFila();
        if (ac.getElemento(i-1,j)instanceof Celula ){
            if(!ac.getElemento(i-1,j).isVivo()&&ac.getElemento(i,j).isVivo()){
                ac.getElemento(i-1,j).rejuvenezca();
                this.estadoSiguiente=MUERTA;
            }
        }
        if(super.edad()>=2)
        this.estadoSiguiente=MUERTA;
    }
	
	public String getIndicador(){
		return "Re";
	}
	
}
