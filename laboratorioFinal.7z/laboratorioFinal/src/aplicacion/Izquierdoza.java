package aplicacion;
import java.awt.Color;

/**
 * Write a description of class Izquierdozas here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Izquierdoza extends Celula
{
    /**
       * Constructor for objects of class Izquierdozas
     */
    public Izquierdoza(AutomataCelular ac,int fila, int columna)
    {
        super(ac,fila,columna);
        this.color=color.red;
    }
    public Color getColor(){
        return this.color;
    }
    public void decida(AutomataCelular ac){
        int j = getColumna();
        int i = getFila();
        if (j!=19 && ac.getElemento(i,j+1) instanceof Celula || super.edad()>=2){
            super.estadoSiguiente=MUERTA;
        }
    }
	
	public String getIndicador(){
		return "Iz";
	}
	
}

