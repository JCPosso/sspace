package aplicacion;
public class automataException extends Exception{

    public static final String  BOTON_EN_CONSTRUCCION= "Opcion en construccion";
	public static final String  ARCHIVO_NO_EXISTE= "El archivo no es compatible ,intente de nuevo";
	public static final String  ERROR_AL_ABRIR= "Hubo un error al intentar abrir el archvo por favor intente de nuevo";
    public automataException(String message){
		super(message);
	}
}