package aplicacion;

import java.util.*;
import java.io.*;
import java.io.Serializable;
public class AutomataCelular  implements Serializable{

    static private int LONGITUD=20;
    private  Elemento[][] automata;
	private PrintWriter errores;
        
   public AutomataCelular() {
        automata=new Elemento[LONGITUD][LONGITUD];
        for (int f=0;f<LONGITUD;f++){
            for (int c=0;c<LONGITUD;c++){
                automata[f][c]=null;
            }
        }
        algunosElementos();
    }

    public int  getLongitud(){
        return LONGITUD;
    }

    public  Elemento getElemento(int f,int c){
        return automata[f][c];
    }
    
    public void setElemento(int f, int c, Elemento nueva){
        automata[f][c]=nueva;
    }
	public void salve(File unAutomata) throws  automataException {
			try {try(ObjectOutputStream out = new ObjectOutputStream(
		            new FileOutputStream(unAutomata.getAbsolutePath()+".dat"))) {
		        out.writeObject(automata);
				out.close();
		}
			}catch(IOException e){
				throw new automataException(automataException.ARCHIVO_NO_EXISTE);
			}
	}
	public  void abrir(File unAutomata) throws automataException, ClassNotFoundException {
	    try{try (ObjectInputStream in = new ObjectInputStream(
	            new FileInputStream(unAutomata.getAbsolutePath()))) {
	        automata= (Elemento[][]) in.readObject();
	    }
			}catch(IOException e){
				throw new automataException(automataException.ERROR_AL_ABRIR);
			}
	}
	public void exportar(File archivo)throws FileNotFoundException{
			PrintWriter pw=new PrintWriter(new FileOutputStream(archivo.getName()+".txt"));
			for(int i=0;i<LONGITUD;i++){
				for(int x=0;x<LONGITUD;x++){
					if (getElemento(i,x)!=null){
						Elemento temp=getElemento(i,x);
						pw.println(temp.getIndicador());
						pw.println(temp.getAttri());
					}
				}
			}
			pw.close();
	}
	
	public void importar(File archivo)  throws FileNotFoundException, IOException {
		
		
			BufferedReader br=new BufferedReader(new FileReader(archivo.getName()));
			String celula=br.readLine();
			
			while (celula!=null){
				String[] atributos=br.readLine().split("x");
				if (celula.equals("Ba")){
					Barrera temp=new Barrera(this,Integer.parseInt(atributos[0]),Integer.parseInt(atributos[1]));
					setElemento(Integer.parseInt(atributos[0]),Integer.parseInt(atributos[1]),temp);
				}
				else if(celula.equals("Ce")){
					Celula temp=new Celula(this,Integer.parseInt(atributos[0]),Integer.parseInt(atributos[1]));
					temp.setEstadoActual(atributos[2].charAt(0));
					temp.setEstadoSiguiente(atributos[3].charAt(0));
					temp.setEdad(Integer.parseInt(atributos[4]));
					setElemento(Integer.parseInt(atributos[0]),Integer.parseInt(atributos[1]),temp);
				}
				else if(celula.equals("Co")){
					Conway temp=new Conway(this,Integer.parseInt(atributos[0]),Integer.parseInt(atributos[1]));
					temp.setEstadoActual(atributos[2].charAt(0));
					temp.setEstadoSiguiente(atributos[3].charAt(0));
					temp.setEdad(Integer.parseInt(atributos[4]));
					setElemento(Integer.parseInt(atributos[0]),Integer.parseInt(atributos[1]),temp);
				}
				else if(celula.equals("Iz")){
					Izquierdoza temp=new Izquierdoza(this,Integer.parseInt(atributos[0]),Integer.parseInt(atributos[1]));
					temp.setEstadoActual(atributos[2].charAt(0));
					temp.setEstadoSiguiente(atributos[3].charAt(0));
					temp.setEdad(Integer.parseInt(atributos[4]));
					setElemento(Integer.parseInt(atributos[0]),Integer.parseInt(atributos[1]),temp);
				}
				else if(celula.equals("Re")){
					Resucitar temp=new Resucitar(this,Integer.parseInt(atributos[0]),Integer.parseInt(atributos[1]));
					temp.setEstadoActual(atributos[2].charAt(0));
					temp.setEstadoSiguiente(atributos[3].charAt(0));
					temp.setEdad(Integer.parseInt(atributos[4]));
					setElemento(Integer.parseInt(atributos[0]),Integer.parseInt(atributos[1]),temp);
				}
				else if(celula.equals("Sa")){
					Sacrificio temp=new Sacrificio(this,Integer.parseInt(atributos[0]),Integer.parseInt(atributos[1]));
					temp.setEstadoActual(atributos[2].charAt(0));
					temp.setEstadoSiguiente(atributos[3].charAt(0));
					temp.setEdad(Integer.parseInt(atributos[4]));
					setElemento(Integer.parseInt(atributos[0]),Integer.parseInt(atributos[1]),temp);
				}
				celula=br.readLine();
			
			
		}
	} 
    
    public void algunosElementos(){
        Celula indiana= new Celula(this , 1,1);
        automata[1][1]=indiana;
        Celula qa = new Celula(this , 2,2);
        automata[2][2]= qa;
        Celula marx = new Izquierdoza(this , 2,3);
        automata[2][3]= marx;
        Elemento egels = new Barrera(this , 6,6);
        automata[6][6]= egels;
        Elemento trip = new Barrera(this , 2,6);
        automata[2][6]= trip;
        Celula bee = new Sacrificio(this , 1,0);
        automata[1][0]= bee;
        Celula aa = new Celula(this , 3,2);
        automata[3][2]= aa;
        Celula to = new Resucitar(this ,2,0);
        automata[2][0]= to;
        Celula ws = new Celula(this , 4,3);
        automata[4][3]= ws;
        Celula qasws = new Celula(this , 4,1);
        automata[4][1]= qasws;
        Celula conww = new Conway(this , 5,1);
        automata[5][1]= conww;
        Celula qsadw = new Celula(this , 2,4);
        automata[2][4]= qsadw;
        Celula con = new Conway(this , 6,1);
        automata[6][1]= con;
        Celula con2 = new Conway(this , 6,2);
        automata[6][2]= con2;
    }
    public  void ticTac(){
        for (int i=0;i<LONGITUD;i++){
            for (int j=0;j<LONGITUD;j++){
                if (automata[i][j] instanceof Celula) {
                    automata[i][j].cambie();
                    automata[i][j].decida(this);
                }
                if( automata[i][j]==null){
                    //if (automata[i][j].verificar(this,i,j)==3){
                    //    Celula nueva= new Conway(this,i,j);
                    //}d
                }
            }
        }
    }
}