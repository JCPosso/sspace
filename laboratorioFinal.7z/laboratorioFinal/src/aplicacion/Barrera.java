package aplicacion;
import java.awt.Color;
import java.io.Serializable;
public class Barrera implements Elemento,Serializable{
    private AutomataCelular automata;
    private int fila,columna;
    protected Color color;
    public int edad(){return 15;}
    public void decida(){return;}
    public  void cambie(){return;}
    public  void muera(){return;}
    public  void decida(AutomataCelular ac){return;}
    public  boolean isVivo(){return true;}
    public  void rejuvenezca(){return;}
	
    public Barrera (AutomataCelular ac,int fila, int columna){
     automata=ac;
     this.fila=fila;
     this.columna=columna;
     automata.setElemento(fila,columna,(Elemento)this);
     this.color=Color.green;
    }
    public Color getColor(){
        return this.color;
    }
	
	public String getIndicador(){
		return "Ba";
	}
	
	public String getAttri(){
		return Integer.toString(fila)+"x"+Integer.toString(columna);
	}
}