package aplicacion;
import java.awt.Color;
import java.util.ArrayList;
/**
 * Write a description of class Conway here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Conway extends Celula 
{
    private int celulasVivas;
    private int celdaVacia;
    /**
       * Constructor for objects of class Izquierdozas
     */
    
    public Conway(AutomataCelular ac,int fila, int columna)
    {
        super(ac,fila,columna);
        this.color=color.blue;
        celulasVivas=0;
        celdaVacia=0;
    }
    public Color getColor(){
        return this.color;
    }
    public void decida(AutomataCelular ac){
        Integer[] I= {-1,0,1,1,-1,1,-1,0,1};
        Integer[] J= {-1,-1,-1,0,0,1,1,1,1};
        celulasVivas=0;
        int jj = this.getColumna();
        int ii = this.getFila();
        for (int i=0 ;i<8;i++){
                if(ac.getElemento(ii+I[i],jj+J[i]) instanceof Celula ){
                celulasVivas++;
                }
            }
        if((celulasVivas==2||celulasVivas==3) && this.isVivo()){
            this.estadoSiguiente=VIVA;
        }
        if ( !(this.isVivo())&&celulasVivas==3){
            this.rejuvenezca();
        }
        if((celulasVivas==1||celulasVivas>3) && this.isVivo()){
            this.estadoSiguiente=MUERTA;
        }
    }
	
	public String getIndicador(){
		return "Co";
	}

}